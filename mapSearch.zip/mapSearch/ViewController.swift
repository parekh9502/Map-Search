//
//  ViewController.swift
//  mapSearch
//
//  Created by Pritesh Parekh on 7/15/17.
//  Copyright © 2017 Pritesh Parekh. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func searchBtn(_ sender: Any) {
        let searchcontroller = UISearchController(searchResultsController: nil)
        searchcontroller.searchBar.delegate = self
        present(searchcontroller, animated: true, completion: nil)
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
      //Ignoring User
        UIApplication.shared.beginIgnoringInteractionEvents()
       
        
        //Activity Indicator
        let activityindicator = UIActivityIndicatorView()
        activityindicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        activityindicator.center = self.view.center
        activityindicator.hidesWhenStopped = true
        activityindicator.startAnimating()
        
        self.view.addSubview(activityindicator)
        //Hide search bar
        searchBar.resignFirstResponder()
        dismiss(animated: true, completion: nil)
        
        //Create search request
        let searchrequest = MKLocalSearchRequest()
        searchrequest.naturalLanguageQuery = searchBar.text
        
        
        
        let activesearch = MKLocalSearch(request: searchrequest)
        
        
        activesearch.start {
            (response, error) in
            
            activityindicator.stopAnimating()
            UIApplication.shared.beginIgnoringInteractionEvents()
            
            if response == nil {
                print("ERROR")
            }
            
            else {
                
                
                //Remove annotations
                let annotations = self.mapView.annotations
                self.mapView.removeAnnotations(annotations)
                
                
                //Getting data
                let latitude = response?.boundingRegion.center.latitude
                let longitude = response?.boundingRegion.center.longitude
                
                
                //Create annotation
                let annotation = MKPointAnnotation()
                annotation.title = searchBar.text
                annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
                self.mapView.addAnnotation(annotation)
                
                
                //Zooming in an annotation
                let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                let span = MKCoordinateSpanMake(0.1, 0.1)
                let region = MKCoordinateRegionMake(coordinate, span)
                self.mapView.setRegion(region, animated: true)
                
                
                
                
            }
            
            
            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

